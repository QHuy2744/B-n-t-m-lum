# ANIUX AI Admin Phụ — mã nguồn APK

## Lưu ý
Đây là bộ khung app Android + workflow build APK. App chưa thể điều khiển backend thực tế cho tới khi backend triển khai các endpoint helper và quyền tương ứng. Không đưa Owner token, NVNMC API key, dashboard-secret, owner-secret hoặc `.env` vào APK/GitHub.

## Vì sao GitHub Actions báo “does not contain a Gradle build”?
Lỗi đó nghĩa là repository chỉ có file workflow hoặc mã nguồn Android đang nằm ngoài thư mục Gradle mà lệnh build đang chạy. Cần có đủ `settings.gradle`, `build.gradle`, `gradle.properties`, và thư mục `app/` chứa `app/build.gradle` cùng mã nguồn.

## Cách cài vào repository hiện tại
1. Tải ZIP và giải nén trên điện thoại.
2. Trong repository GitHub, vào **Add file → Upload files**.
3. Tải **toàn bộ nội dung đã giải nén** lên, gồm `settings.gradle`, `build.gradle`, `gradle.properties`, thư mục `app/`, và thư mục `.github/workflows/`. Không chỉ tải file `build-apk.yml`.
4. Nếu GitHub đang có sẵn `build-apk.yml`, có thể thay bằng file cùng tên trong gói này. Giữ các tệp mã nguồn ở root repository nếu có thể. Workflow mới cũng có thể tự tìm dự án nếu nó nằm trong thư mục con.
5. Commit. Vào **Actions → Build ANIUX AI Admin Phu APK → Run workflow**.
6. Khi job thành công (màu xanh), mở lần chạy và tải artifact `ANIUX-AI-Admin-Phu-debug-apk`; giải nén artifact để lấy `app-debug.apk`.

## API backend cần có trước khi dùng tính năng quản trị
- `POST /api/helper/login` body `{"key":"MÃ_ADMIN_PHỤ"}`; trả `{"token":"token-phiên-ngắn-hạn","permissions":["status","players","announce","kick"]}`.
- `GET /api/helper/status` trả trạng thái server; quyền `status`.
- `GET /api/helper/players` trả danh sách người chơi; quyền `players`.
- `POST /api/helper/announce` body `{"message":"..."}`; quyền `announce`.
- `POST /api/helper/kick` body `{"player":"Tên","reason":"Lý do"}`; quyền `kick`.

Backend phải xác minh token và quyền ở mỗi endpoint, cho phép thu hồi mã, đặt hạn token, giới hạn tần suất và kiểm tra dữ liệu. Không cung cấp console tự do cho admin phụ.
