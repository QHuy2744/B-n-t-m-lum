package com.aniux.adminphu;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Set<String> permissions = new HashSet<>();
    private String helperToken = "";
    private EditText baseUrl, keyInput, messageInput, playerInput, reasonInput;
    private TextView status, result, title;
    private LinearLayout actions;
    private int cyan = Color.rgb(70, 210, 255);
    private int panel = Color.argb(225, 10, 19, 38);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(4, 9, 20));
        getWindow().setNavigationBarColor(Color.rgb(4, 9, 20));
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20), dp(28), dp(20), dp(28));
        root.setBackgroundResource(R.drawable.bg_anime);
        // Artwork is included as a local asset; keep the interface readable with dark cards.
        sc.addView(root); setContentView(sc);

        TextView brand = new TextView(this); brand.setText("ANIUX AI"); brand.setTextColor(cyan); brand.setTextSize(13); brand.setLetterSpacing(.18f); brand.setTypeface(null, Typeface.BOLD); root.addView(brand);
        title = new TextView(this); title.setText("ADMIN PHỤ"); title.setTextColor(Color.WHITE); title.setTextSize(30); title.setTypeface(null, Typeface.BOLD); title.setPadding(0, dp(2), 0, dp(4)); root.addView(title);
        TextView sub = new TextView(this); sub.setText("BẢNG ĐIỀU KHIỂN SỰ KIỆN • QUYỀN GIỚI HẠN"); sub.setTextColor(Color.LTGRAY); sub.setTextSize(11); root.addView(sub);
        status = new TextView(this); status.setText("● Chưa đăng nhập"); status.setTextColor(cyan); status.setTextSize(13); status.setPadding(0, dp(18), 0, dp(10)); root.addView(status);

        LinearLayout login = card(root, "KẾT NỐI BACKEND");
        baseUrl = field("URL backend HTTPS (ví dụ https://ten-mien-cua-ban)", "https://"); login.addView(baseUrl);
        keyInput = field("Mã truy cập được cấp cho admin phụ", ""); keyInput.setInputType(0x00000081); login.addView(keyInput);
        Button enter = button("ĐĂNG NHẬP BẰNG MÃ PHỤ"); login.addView(enter);
        enter.setOnClickListener(v -> login());

        actions = new LinearLayout(this); actions.setOrientation(LinearLayout.VERTICAL); actions.setVisibility(View.GONE); root.addView(actions);
        LinearLayout info = card(actions, "THAO TÁC ĐƯỢC CẤP QUYỀN");
        Button refresh = button("KIỂM TRA TRẠNG THÁI SERVER"); info.addView(refresh); refresh.setOnClickListener(v -> call("GET", "/api/helper/status", null, "status"));
        Button players = button("XEM DANH SÁCH NGƯỜI CHƠI"); info.addView(players); players.setOnClickListener(v -> call("GET", "/api/helper/players", null, "players"));
        messageInput = field("Nội dung thông báo sự kiện", ""); info.addView(messageInput);
        Button announce = button("GỬI THÔNG BÁO SỰ KIỆN"); info.addView(announce); announce.setOnClickListener(v -> postText("/api/helper/announce", "message", messageInput.getText().toString(), "announce"));
        playerInput = field("Tên người chơi cần kick", ""); info.addView(playerInput);
        reasonInput = field("Lý do (không bắt buộc)", "Vi phạm quy định sự kiện"); info.addView(reasonInput);
        Button kick = button("KICK NGƯỜI CHƠI"); info.addView(kick); kick.setOnClickListener(v -> kickPlayer());
        Button logout = button("ĐĂNG XUẤT / XÓA PHIÊN"); info.addView(logout); logout.setOnClickListener(v -> { helperToken=""; permissions.clear(); actions.setVisibility(View.GONE); status.setText("● Đã đăng xuất"); result.setText(""); });
        result = new TextView(this); result.setTextColor(Color.WHITE); result.setTextSize(13); result.setPadding(dp(14), dp(14), dp(14), dp(14)); result.setBackground(round(panel, 16)); root.addView(result, new LinearLayout.LayoutParams(-1, -2));
        TextView foot = new TextView(this); foot.setText("BẢO MẬT: APK không chứa Owner token hay NVNMC API key. Máy chủ phải kiểm tra quyền ở mọi endpoint."); foot.setTextColor(Color.GRAY); foot.setTextSize(11); foot.setPadding(0, dp(16), 0, 0); root.addView(foot);
    }

    private LinearLayout card(LinearLayout parent, String label) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(14), dp(14), dp(14), dp(14)); box.setBackground(round(panel, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin=dp(14); parent.addView(box, lp);
        TextView t = new TextView(this); t.setText(label); t.setTextColor(cyan); t.setTextSize(12); t.setTypeface(null, Typeface.BOLD); t.setPadding(0,0,0,dp(10)); box.addView(t); return box;
    }
    private EditText field(String hint, String value) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setText(value); e.setHint(hint); e.setHintTextColor(Color.GRAY); e.setTextColor(Color.WHITE); e.setTextSize(13); e.setPadding(dp(12), dp(8), dp(12), dp(8)); e.setBackground(round(Color.rgb(17,29,50), 10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin=dp(9); e.setLayoutParams(lp); return e;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(11); b.setAllCaps(false); b.setTypeface(null, Typeface.BOLD); b.setBackground(round(Color.rgb(18, 83, 132), 12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin=dp(8); b.setLayoutParams(lp); return b;
    }
    private GradientDrawable round(int color, int radius) { GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); d.setStroke(dp(1), Color.argb(90, 70,210,255)); return d; }
    private int dp(float n) { return (int)(n*getResources().getDisplayMetrics().density+.5f); }
    private String apiBase() { return baseUrl.getText().toString().trim().replaceAll("/+$", ""); }

    private void login() {
        String base=apiBase(), key=keyInput.getText().toString().trim();
        if (!base.startsWith("https://") || key.isEmpty()) { show("Nhập URL HTTPS hợp lệ và mã admin phụ."); return; }
        status.setText("● Đang xác thực...");
        io.execute(() -> {
            try {
                JSONObject body=new JSONObject(); body.put("key", key);
                JSONObject resp=request("POST", base+"/api/helper/login", null, body);
                String token=resp.optString("token", "");
                if (token.isEmpty()) throw new Exception("Backend không trả token.");
                JSONArray arr=resp.optJSONArray("permissions"); Set<String> perms=new HashSet<>();
                if (arr!=null) for(int i=0;i<arr.length();i++) perms.add(arr.optString(i));
                runOnUiThread(() -> {
                    helperToken=token; permissions.clear(); permissions.addAll(perms); actions.setVisibility(View.VISIBLE);
                    status.setText("● Đã xác thực • quyền: "+permissions);
                    setPermissionButtons(); show("Đăng nhập thành công. Các nút được bật theo quyền backend trả về.");
                });
            } catch(Exception ex) { runOnUiThread(() -> { status.setText("● Đăng nhập thất bại"); show("Lỗi: "+ex.getMessage()); }); }
        });
    }
    private void setPermissionButtons() {
        for(int i=0;i<actions.getChildCount();i++) {
            View v=actions.getChildAt(i);
            if (!(v instanceof LinearLayout)) continue;
            LinearLayout box=(LinearLayout)v;
            for(int j=0;j<box.getChildCount();j++) if(box.getChildAt(j) instanceof Button) {
                Button b=(Button)box.getChildAt(j); String s=b.getText().toString();
                if(s.contains("TRẠNG THÁI")) b.setVisibility(permissions.contains("status")?View.VISIBLE:View.GONE);
                else if(s.contains("DANH SÁCH")) b.setVisibility(permissions.contains("players")?View.VISIBLE:View.GONE);
                else if(s.contains("THÔNG BÁO")) b.setVisibility(permissions.contains("announce")?View.VISIBLE:View.GONE);
                else if(s.contains("KICK")) b.setVisibility(permissions.contains("kick")?View.VISIBLE:View.GONE);
            }
        }
    }
    private void postText(String path, String field, String value, String permission) {
        if (!permissions.contains(permission)) { show("Mã của bạn không có quyền: "+permission); return; }
        if(value.trim().isEmpty()) { show("Bạn chưa nhập nội dung."); return; }
        try { JSONObject b=new JSONObject(); b.put(field,value.trim()); call("POST",path,b,permission); } catch(Exception e){show(e.getMessage());}
    }
    private void kickPlayer() {
        if(!permissions.contains("kick")){show("Mã của bạn không có quyền kick.");return;}
        String name=playerInput.getText().toString().trim(); if(name.isEmpty()){show("Nhập tên người chơi.");return;}
        try { JSONObject b=new JSONObject(); b.put("player",name); b.put("reason",reasonInput.getText().toString().trim()); call("POST","/api/helper/kick",b,"kick"); } catch(Exception e){show(e.getMessage());}
    }
    private void call(String method, String path, JSONObject body, String permission) {
        if(helperToken.isEmpty()){show("Hãy đăng nhập trước.");return;}
        if(!permissions.contains(permission)){show("Mã của bạn không có quyền: "+permission);return;}
        status.setText("● Đang xử lý...");
        io.execute(() -> { try { JSONObject resp=request(method,apiBase()+path,helperToken,body); runOnUiThread(()->{status.setText("● Hoàn tất yêu cầu");show(resp.toString());}); }
          catch(Exception ex){runOnUiThread(()->{status.setText("● Yêu cầu thất bại");show("Lỗi: "+ex.getMessage());});} });
    }
    private JSONObject request(String method,String url,String token,JSONObject body) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setRequestMethod(method); c.setConnectTimeout(12000); c.setReadTimeout(15000); c.setRequestProperty("Accept","application/json");
        if(token!=null)c.setRequestProperty("Authorization","Bearer "+token);
        if(body!=null){c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");try(OutputStream o=c.getOutputStream()){o.write(body.toString().getBytes(StandardCharsets.UTF_8));}}
        int code=c.getResponseCode(); InputStream in=(code>=200&&code<400)?c.getInputStream():c.getErrorStream(); StringBuilder sb=new StringBuilder();
        if(in!=null)try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)sb.append(line);}
        c.disconnect(); if(code<200||code>=300)throw new Exception("HTTP "+code+": "+sb);
        return new JSONObject(sb.length()==0?"{}":sb.toString());
    }
    private void show(String s) { if(result!=null) result.setText(s); }
    @Override protected void onDestroy(){super.onDestroy();io.shutdownNow();}
}
