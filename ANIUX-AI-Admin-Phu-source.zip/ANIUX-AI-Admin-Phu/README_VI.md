# ANIUX AI Admin Phụ — mã nguồn APK

## Lưu ý quan trọng
Đây là **bộ khung APK + luồng build tự động**, chưa thể điều khiển backend cho đến khi backend của bạn có các endpoint `/api/helper/*` theo hợp đồng dưới đây. Màn hình APK không thể tự cấp quyền bảo mật; backend phải xác thực mã và quyền ở mỗi request.

APK chỉ chứa giao diện và gọi HTTPS. **Không đặt Owner token, NVNMC API key, dashboard-secret hay owner-secret vào APK.** Không dùng `http://` cho backend thật.

## API backend cần có
- `POST /api/helper/login` body `{"key":"MÃ_ADMIN_PHỤ"}`; trả `{"token":"token-phiên-ngắn-hạn","permissions":["status","players","announce","kick"]}`.
- `GET /api/helper/status` trả trạng thái máy chủ; quyền `status`.
- `GET /api/helper/players` trả danh sách người chơi; quyền `players`.
- `POST /api/helper/announce` body `{"message":"..."}`; quyền `announce`.
- `POST /api/helper/kick` body `{"player":"Tên","reason":"Lý do"}`; quyền `kick`.

Mỗi endpoint cần kiểm tra token, quyền tương ứng, giới hạn tần suất và dữ liệu đầu vào ở phía backend. Mã bị thu hồi phải hết hiệu lực; token phiên nên hết hạn. Không chuyển lệnh console tự do từ APK.

## Build APK bằng GitHub Actions (không cài SDK trong Termux)
1. Giải nén ZIP.
2. Tạo **repository riêng tư mới** trên GitHub, ví dụ `aniux-admin-phu` (không dùng repo OCR nếu muốn tách biệt).
3. Đưa toàn bộ nội dung trong thư mục này lên repo; không tải file `.env`, token, khóa bí mật hay dữ liệu server lên GitHub.
4. Mở repo → tab **Actions** → workflow **Build ANIUX AI Admin Phu APK** → **Run workflow**.
5. Khi workflow xanh, mở lần chạy → mục **Artifacts** → tải `ANIUX-AI-Admin-Phu-debug-apk` và giải nén để lấy `app-debug.apk`.

Workflow cũng tự chạy khi push thay đổi source lên nhánh `main`.

## Backend URL
Trong APK, nhập URL HTTPS công khai của backend đang chạy (không nhập `127.0.0.1` vì đó là chính điện thoại của người dùng APK). Mã admin phụ phải được tạo và quản lý ở backend; không hard-code một mã dùng chung trong source APK.
